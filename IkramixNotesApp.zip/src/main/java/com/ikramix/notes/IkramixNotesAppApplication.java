package com.ikramix.notes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IkramixNotesAppApplication {
    public static void main(String[] args) {
        SpringApplication.run(IkramixNotesAppApplication.class, args);
    }
}
